package com.cascv.oas.server.aspectj;

// multiple data source
public class DataSourceName
{
    // main 
    public static final String MASTER = "master";

    // slave 
    public static final String SLAVE = "slave";
}
